import cards_tools

# 读取数据
cards_tools.card_read()
while True:
    cards_tools.show_menu()
    action_str=input("执行操作：")
    print(f"您选择的操作是[%s]"% action_str)

    #执行功能
    if action_str in["1","2","3","4"]:
        # 新增名片
        if action_str == "1":
            cards_tools.new_card()
        # 显示全部
        elif action_str == "2":
            cards_tools.show_all()
        # 查询名片
        elif action_str == "3":
            cards_tools.search_card()
        #存储数据
        elif action_str == "4":
            cards_tools.card_save()


    #退出
    elif action_str =="0":
        print("退出成功")
        break
    #非法输入
    else:
        print("输入不正确，请重试")
