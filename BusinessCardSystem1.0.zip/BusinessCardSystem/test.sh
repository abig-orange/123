#!/bin/sh

python3 cards_main.py
